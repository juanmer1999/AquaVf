
import pandas as pd
import numpy as np
import requests
from sklearn.preprocessing import LabelEncoder  #para la transformación de los datos
from sklearn import tree  # para modelo de arbol
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.neighbors import KNeighborsClassifier  # para modelo KNN
from sklearn.neural_network import MLPRegressor  # para la red neuronal
from sklearn.linear_model import LogisticRegressionCV  # para modelo de rgresión logística
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# Supongamos que tienes una función para obtener los datos de la API
def get_api_data():
    api_url = 'http://localhost:3300/ph' # URL de la API (ajusta según tu configuración)
    response = requests.get(api_url)
    data = response.json()  # Suponiendo que los datos se devuelven en formato JSON
    return data

# Obtener los datos de la API
api_data = get_api_data()

# Convertir los datos en un DataFrame de pandas
df_reg = pd.DataFrame(api_data)

# Verificar si hay valores nulos en cada columna
##null_check = df_reg.isnull().any()

##print(null_check)
print(df_reg.head())
print(df_reg.dtypes)
from sklearn.preprocessing import LabelEncoder

print(df_reg.head())
print(df_reg.dtypes)
# Reemplazar 0 por NaN en todas las columnas excepto en 'Potability' 
df_reg[df_reg.columns.difference(['Potability'])] = df_reg[df_reg.columns.difference(['Potability'])].replace(0, np.nan)

# Verificar si hay valores nulos en cada columna
print(df_reg.isnull().any())


print(df_reg.isnull().any())
print(df_reg.head())
missing_data_count = df_reg.isnull().sum()
print(missing_data_count)
print(df_reg.head())
#------------------------
Promph = df_reg['ph'].mean()
print("ph de edad",Promph)

PromHardness = df_reg['Hardness'].mean()
print("Hardness",PromHardness)

PromSolids = df_reg['Solids'].mean()
print("Solids",PromSolids)

PromChloramines = df_reg['Chloramines'].mean()
print("Chloramines",PromChloramines)

PromSulfate = df_reg['Sulfate'].mean()
print("Sulfate",PromSulfate)

PromConductivity= df_reg['Conductivity'].mean()
print("Conductivity",PromConductivity)


PromOrganic_carbon= df_reg['Organic_carbon'].mean()
print("Organic_carbon",PromOrganic_carbon)


PromTrihalomethanes = df_reg['Trihalomethanes'].mean()
print("Trihalomethanes",PromTrihalomethanes)


PromTurbidity = df_reg['Turbidity'].mean()
print("Turbidity",PromTurbidity)

#---------------------

df_reg['ph']=df_reg['ph'].replace(np.nan, Promph)
df_reg['Hardness']=df_reg['Hardness'].replace(np.nan, PromHardness)
df_reg['Solids']=df_reg['Solids'].replace(np.nan, PromSolids)
df_reg['Chloramines']=df_reg['Chloramines'].replace(np.nan, PromChloramines)
df_reg['Sulfate']=df_reg['Sulfate'].replace(np.nan, PromSulfate)
df_reg['Conductivity']=df_reg['Conductivity'].replace(np.nan, PromConductivity)
df_reg['Organic_carbon']=df_reg['Organic_carbon'].replace(np.nan, PromOrganic_carbon)
df_reg['Trihalomethanes']=df_reg['Trihalomethanes'].replace(np.nan, PromTrihalomethanes)
df_reg['Turbidity']=df_reg['Turbidity'].replace(np.nan, PromTurbidity)


print(df_reg.isnull().any())
missing_data_count = df_reg.isnull().sum()
print(missing_data_count)
print(df_reg.head())



# Para modelos de regresión multimple y red neuronal
X_regRm = df_reg[['ph', 'Hardness', 'Solids', 'Chloramines', 'Sulfate', 'Conductivity','Organic_carbon','Trihalomethanes','Turbidity']]
y_regRm = df_reg['Potability']


#partición de conjunto de datos regresion multiple y neuronal
X_trainRm, X_testRm, Y_trainRm, Y_testRm = train_test_split(X_regRm, y_regRm, test_size=0.2)

#------------------------------------------------

#clasificacion
# Variables independientes
X_clas = df_reg[['ph', 'Hardness', 'Solids', 'Chloramines', 'Sulfate', 'Conductivity','Organic_carbon','Trihalomethanes','Turbidity']]
# Variable dependiente
y_clas = df_reg['Potability']



#partición de conjunto de datos clasificacion
X_trainC, X_testC, Y_trainC, Y_testC = train_test_split(X_clas, y_clas, test_size=0.2)


#Regresión logística

# Selección de algoritmo
Rlog = LogisticRegressionCV(max_iter = 10000)# se demora un poco

# Entrenamiento
Rlog.fit(X_trainC,Y_trainC)

# Prueba
Rlog.predict(X_testC)



print("Modelo de Clasificación 1 Regresión logística -  Precisión: ", format(Rlog.score(X_trainC,Y_trainC)))


###-----


#Arbol de decision

# Selección de algoritmo
AD = tree.DecisionTreeClassifier()

# Entrenamiento
AD.fit(X_trainC,Y_trainC)


AD.predict(X_testC)

print("Precisión de entrenamiento de arbol de decisión: ",format(AD.score(X_trainC,Y_trainC)))


#KNN
# Selección de algoritmo
KNN = KNeighborsClassifier(n_neighbors=5)

# Entrenamiento
KNN.fit(X_trainC,Y_trainC)

MLPRegressor
KNN.predict(X_testC)

print("Precisión de entrenamiento de vecino más cercano: ",format(KNN.score(X_trainC,Y_trainC)))



# Crear una instancia del clasificador KNN con, por ejemplo, 5 vecinos
KNN = KNeighborsClassifier(n_neighbors=5)

# Entrenar el modelo KNN con los datos de entrenamiento de clasificación
KNN.fit(X_trainC, Y_trainC)

# Definir los valores para la nueva instancia que deseas predecir
nueva_instancia = np.array([[0, 0, 0, 0, 0, 0, 0,0,0]])

# Hacer la predicción utilizando el modelo KNN
prediccion = KNN.predict(nueva_instancia)

# Imprimir la predicción
print("Predicción utilizando KNN:", prediccion)

# Calcula la matriz de correlación
correlation_matrix = df_reg.corr()

# Crea un mapa de correlación utilizando seaborn
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5)
plt.title('Mapa de Correlación')
plt.show()