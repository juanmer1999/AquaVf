import pandas as pd
from train_model import df_reg
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import joblib

# Variables independientes para clasificación
print(df_reg.head())
X_clas = df_reg[['ph', 'Hardness', 'Solids', 'Chloramines', 'Sulfate', 'Conductivity', 'Organic_carbon', 'Trihalomethanes', 'Turbidity']]

# Variable dependiente para clasificación
y_clas = df_reg['Potability']

# Dividir los datos en conjuntos de entrenamiento y prueba con random_state
X_train, X_test, y_train, y_test = train_test_split(X_clas, y_clas, test_size=0.2, random_state=42)

# Escalar las características
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Selección de algoritmo KNN con random_state
KNN = KNeighborsClassifier(n_neighbors=10)

# Entrenamiento
KNN.fit(X_train_scaled, y_train)

# Predecir en el conjunto de prueba
y_pred = KNN.predict(X_test_scaled)

# Calcular la precisión
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy}')

# Guardar el modelo entrenado
model_path = "modelo_knn.pkl"
joblib.dump(KNN, model_path)
