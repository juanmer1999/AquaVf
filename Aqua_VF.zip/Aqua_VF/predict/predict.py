from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import os

app = Flask(__name__)
CORS(app)
# Cargar el modelo KNN
model_path = "./modelo_knn.pkl"



if os.path.exists(model_path):
    modelo_knn = joblib.load(model_path)
else:
    raise FileNotFoundError(f"No se encontró el archivo {model_path}")

@app.route('/predict', methods=['POST'])
def predecir_potabilidad():
    datos = request.json
    # Convertir los datos a valores numéricos
    try:
        X = [[float(datos['ph']), float(datos['Hardness']), float(datos['Solids']), float(datos['Chloramines']), float(datos['Sulfate']), float(datos['Conductivity']), float(datos['Organic_carbon']), float(datos['Trihalomethanes']), float(datos['Turbidity'])]]
    except ValueError as e:
        return jsonify({'error': 'Los datos no pudieron ser convertidos a valores numéricos'}), 400

    # Realizar la predicción
    potabilidad = modelo_knn.predict(X)
    # Enviar la respuesta como JSON
    return jsonify({'Potability': int(potabilidad[0])})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True) 
    
