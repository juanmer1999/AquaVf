import React from 'react';
import useFetchUsers from '../../AuthContext/FetchUsers';
import './HomePac.css';
import HomeIMG from '../../../assets/img/home_water.jpg';
import QualityWater from '../../QualityWater/QualityWater'; // Ruta relativa para importar QualityWater.jsx

const HomePac = () => {
    const { userData, loading, error } = useFetchUsers();

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;

    return (
        <section className='HomePac'
            style={{
                backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.1)), url('${HomeIMG}')`
            }}
        >

            <div className="contentHomePac">
                <div className="greeting">
                    <p>Bienvenido, {userData ? `${userData.name} ${userData.lastName}` : "Usuario"}</p>
                </div>
                <div className="welcomeText">
                    <h3>Sistema de monitoreo y predicción de calidad del agua</h3>
                </div>

                {/* Aquí se integra el componente QualityWater */}
                <QualityWater />

                <div className='BlogHome'>
                <button><span>Visitar blog</span></button>
                </div>
               
            </div>
        </section>
    );
}

export default HomePac;
