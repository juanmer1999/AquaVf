import React from 'react'

const NavBar = () => {
  return (
    <div></div>
  )
}

export default NavBar