import React, { useState } from 'react';
import './QualityWater.css'; 

const QualityWater = () => {
  const [formData, setFormData] = useState({
    ph: '7.788',
    Hardness: '212.691',
    Solids: '29879.060',
    Chloramines: '6.998',
    Sulfate: '360.668',
    Conductivity: '359.569',
    Organic_carbon: '14.828232232323',
    Trihalomethanes: '83.8563',
    Turbidity: '3.3687'
  });

  const [prediction, setPrediction] = useState(null);

  const handleChange = (e) => {
    const value = e.target.value.trim(); 
    const newValue = value === '' ? '' : parseFloat(value); // Convertir a número flotante si no es una cadena vacía
  
    setFormData({
      ...formData,
      [e.target.name]: newValue
    });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://127.0.0.1:5001/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      const result = await response.json();
      setPrediction(result.Potability);
    } catch (error) {
      console.error('Error predicting water potability:', error);
    }
  };

  return (
    <div className="quality-water-container">
      <h2>Calidad del Agua - Predicción Manual</h2>
      <form onSubmit={handleSubmit}>
        <label className="input-label">
          pH:
          <input type="text" name="ph" value={formData.ph} onChange={handleChange} />
        </label>
  
        <label className="input-label">
          Dureza:
          <input type="text" name="Hardness" value={formData.Hardness} onChange={handleChange} />
        </label>
 
        <label className="input-label">
          Sólidos disueltos:
          <input type="text" name="Solids" value={formData.Solids} onChange={handleChange} />
        </label>
   
        <label className="input-label">
          Cloraminas:
          <input type="text" name="Chloramines" value={formData.Chloramines} onChange={handleChange} />
        </label>
        <label className="input-label">
          Sulfato:
          <input type="text" name="Sulfate" value={formData.Sulfate} onChange={handleChange} />
        </label>
        <label className="input-label">
          Conductividad:
          <input type="text" name="Conductivity" value={formData.Conductivity} onChange={handleChange} />
        </label>
        <label className="input-label">
          Carbono orgánico:
          <input type="text" name="Organic_carbon" value={formData.Organic_carbon} onChange={handleChange} />
        </label>
        <label className="input-label">
          Trihalometanos:
          <input type="text" name="Trihalomethanes" value={formData.Trihalomethanes} onChange={handleChange} />
        </label>
        <label className="input-label">
          Turbidez:
          <input type="text" name="Turbidity" value={formData.Turbidity} onChange={handleChange} />
        </label>
        <br></br>
        <button type="submit">Predecir</button>
      </form>
      {prediction !== null && (
        <div className="prediction">
          <h3>Predicción de Potabilidad:</h3>
          <p>{prediction === 0 ? "No potable" : "Potable"}</p>
        </div>
      )}
    </div>
  );
};

export default QualityWater;
