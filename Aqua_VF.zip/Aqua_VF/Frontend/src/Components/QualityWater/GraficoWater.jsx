import React, { useState, useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

const QualityWater = () => {
  const [waterData, setWaterData] = useState([]);

  const chartRef = useRef(null);
  const chartInstanceRef = useRef(null); // Referencia para el objeto Chart

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:3300/ph');
        const data = await response.json();
        setWaterData(data);
      } catch (error) {
        console.error('Error fetching water data:', error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const ctx = chartRef.current.getContext('2d');

    if (chartInstanceRef.current) {
      // Destruir el gráfico existente si existe
      chartInstanceRef.current.destroy();
    }

    const potableCount = waterData.filter(water => water.Potability === 1).length;
    const notPotableCount = waterData.filter(water => water.Potability === 0).length;

    chartInstanceRef.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Agua Potable', 'Agua No Potable'],
        datasets: [{
          label: 'Cantidad de agua',
          data: [potableCount, notPotableCount],
          backgroundColor: [
            'rgba(54, 12, 235, 1)',
            'rgba(255, 99, 132, 1)',
          ],
          borderColor: [
            'rgba(54, 162, 235, 1)',
            'rgba(255, 99, 132, 1)',
          ],
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            
            beginAtZero: true
          }
        },
        plugins: {
          legend: {
            labels: {
              color: 'black' 
            }
            
          }
        }
      }
    });
  }, [waterData]);

  return (
    <div className="quality-water-container">
      <h2>Calidad del Agua - Predicción Manual</h2>
      <canvas ref={chartRef} width={400} height={400}></canvas>
    </div>
  );
};

export default QualityWater;
