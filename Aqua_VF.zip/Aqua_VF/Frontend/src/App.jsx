import React, { useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthContext } from './Components/AuthContext/AuthContext';
import Dashboard from './Components/Dashboard/Dashboard';

import LoginForm from './Components/Login/Login';
import SignUp from './Components/SignUp/SignUp';
import GraficoWater from './Components/QualityWater/GraficoWater'; // Importa QualityWater

function App() {
  const { isLoggedIn, loading, userRole } = useContext(AuthContext);

  if (loading) {
    return <div></div>; // Indicación de carga mejorada
  }

  // Construye la ruta dinámica del dashboard en función del rol del usuario
  const dashboardPath = `/DocMe/${userRole}/dashboard`;

  return (
    <Router>
      <Routes>
        <Route path="/DocMe/login" element={!isLoggedIn ? <LoginForm /> : <Navigate to={dashboardPath} />} />
        <Route path="/DocMe/signup" element={!isLoggedIn ? <SignUp /> : <Navigate to={dashboardPath} />} />
        <Route path={dashboardPath} element={isLoggedIn ? <DashboardAndChatBot /> : <Navigate to="/DocMe/login" />} />
        <Route path="*" element={<Navigate to={isLoggedIn ? dashboardPath : "/DocMe/login"} />} />
      </Routes>
    </Router>
  );
}

// Componente que agrupa Dashboard QualityWater
function DashboardAndChatBot() {
  return (
    <>
      <Dashboard />
   
      <GraficoWater/>
    {/* Agrega el componente QualityWater aquí */}
    </>
  );
}

export default App;
