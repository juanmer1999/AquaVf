const mysql = require('mysql');
const conexion = mysql.createConnection(
    {
        host:'mysql-juanmer1999.alwaysdata.net',
        user:'350545',
        password:'G6gnmoso',
        database:'juanmer1999_water'
    }

);
conexion.connect(
    err=>{
        if(err){
            console.log('Error al conectar a la BD: '+err)
        }
        else{
            console.log('Conectado correctamente a la BD')
        }

    }
);

module.exports=conexion;